# Package initialization for evaluation
